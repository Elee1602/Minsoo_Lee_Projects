# Minsoo Lee, minsoole@usc.edu
# ITP 115, Spring 2021
# Final Project
# This file will define the Menu class, which will determine the
# category of each menu item, and have methods to get the menu item,
# print the menu item, and get the number of menu items
from MenuItem import MenuItem

# Define Menu class. This will use objects from MenuItem
class Menu(object):
    # Class variable with 4 categories for menu items
    CATEGORIES = ["Drink", "Appetizer", "Entree", "Dessert"]
    # Instance attributes
    def __init__(self, menuFileName = "menu.csv"):
        # Each instance attribute is initialized to a empty string
        self.drinks = []
        self.appetizers = []
        self.entrees = []
        self.desserts = []
        fileIn = open(menuFileName, "r")
        # Loop through each line in menu.csv
        for line in fileIn:
            line = line.strip()
            menuList = line.split(",")
            # create menu object
            menuObject = MenuItem(menuList[0], menuList[1], menuList[2], menuList[3])
            # determine which category menu item belongs to and append it to the empty lists in instance attributes
            if menuList[1] == "Drink":
                self.drinks.append(menuObject)
            elif menuList[1] == "Appetizer":
                self.appetizers.append(menuObject)
            elif menuList[1] == "Entree":
                self.entrees.append(menuObject)
            elif menuList[1] == "Dessert":
                self.desserts.append(menuObject)
        fileIn.close()
    # getMenuItem function to return MenuItem object
    def getMenuItem(self, category, index):
        # Error checking to make sure category is in menu.categories and index is between 0 and length of list
        if category in Menu.CATEGORIES:
            if category == "Drink":
                if index < len(self.drinks) and index >= 0:
                    return self.drinks[index]
            if category == "Appetizer":
                if index < len(self.appetizers) and index >= 0:
                    return self.appetizers[index]
            if category == "Entree":
                if index < len(self.entrees) and index >= 0:
                    return self.entrees[index]
            if category == "Dessert":
                if index < len(self.desserts) and index >= 0:
                    return self.desserts[index]

    # printMenuItems function to print category and list of menu options
    def printMenuItems(self, category):
        # counter for listing menu items
        menuNum = 0
        # error checking for checking if category valid
        if category in Menu.CATEGORIES:
            if category == "Drink":
                print("-----" + category.upper() + "S-----")
                # loop through each menu and print from menuitem
                for num in self.drinks:
                    print(str(menuNum) + "), " + str(self.drinks[menuNum].name) + " (" + category + "): " + str(self.drinks[menuNum].price))
                    print("\t\t" + str(self.drinks[menuNum].desc))
                    # update menu number
                    menuNum += 1
            if category == "Appetizer":
                print("-----" + category.upper() + "S-----")
                for num in self.appetizers:
                    print(str(menuNum) + "), " + str(self.appetizers[menuNum].name) + " (" + category + "): " + str(self.appetizers[menuNum].price))
                    print("\t\t" + str(self.appetizers[menuNum].desc))
                    menuNum += 1
            if category == "Entree":
                print("-----" + category.upper() + "S-----")
                for num in self.entrees:
                    print(str(menuNum) + "), " + str(self.entrees[menuNum].name) + " (" + category + "): " + str(self.entrees[menuNum].price))
                    print("\t\t" + str(self.entrees[menuNum].desc))
                    menuNum += 1
            if category == "Dessert":
                print("-----" + category.upper() + "S-----")
                for num in self.desserts:
                    print(str(menuNum) + "), " + str(self.desserts[menuNum].name) + " (" + category + "): " + str(self.desserts[menuNum].price))
                    print("\t\t" + str(self.desserts[menuNum].desc))
                    menuNum += 1
    # getNumMenuItems function for getting integer value of how many items there are in each category
    def getNumMenuItems(self, category):
        # error checking for checking if category valid
        if category in Menu.CATEGORIES:
            if category == "Drink":
                return len(self.drinks)
            if category == "Appetizer":
                return len(self.appetizers)
            if category == "Entree":
                return len(self.entrees)
            if category == "Dessert":
                return len(self.desserts)
        else:
            return 0







