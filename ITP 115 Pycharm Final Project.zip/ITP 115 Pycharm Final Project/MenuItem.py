# Minsoo Lee, minsoole@usc.edu
# ITP 115, Spring 2021
# Final Project
# This file will define the MenuItem class, which will have
# get methods for name, category, price, and description of the menu item,
# and a __str__ for printing the menu display

# Define MenuItem class. Represent one item diner can order from menu
class MenuItem(object):
    # Instance attributes
    def __init__(self, name, category, price, description):
        self.name = name
        self.category = category
        self.price = float(price)
        self.desc = description
    # Get methods for instance attributes
    def getName(self):
        return self.name
    def getCategory(self):
        return self.category
    def getPrice(self):
        return self.price
    def getDesc(self):
        return self.desc

    # __str__ for printing
    def __str__(self):
        menuDisplay = self.name + " (" + self.category + "): " + "{:.2f}".format(self.price) + "\n\t" + self.desc
        return menuDisplay


























