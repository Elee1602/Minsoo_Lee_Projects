# Minsoo Lee, minsoole@usc.edu
# ITP 115, Spring 2021
# Final Project
# This file will define the Waiter class, which will have methods to
# add diners, get number of diners, print diner statuses, take orders, print meal cost,
# remove diners, and advance diners through stages
from Menu import Menu
from Diner import Diner

# Define waiter class to represent waiter who guides diner through meal
class Waiter(object):
    # Instance attributes
    def __init__(self, menu):
        self.diners = []
        self.menu = menu

    # addDiner used to Add diner to list of diners
    def addDiner(self, diner):
        self.diners.append(diner)

    # getNumDiners used to return number of diners in list
    def getNumDiners(self):
        return len(self.diners)

    # printDinerStatuses used to group diners by status and print
    def printDinerStatuses(self):
        # loop through list of diner statuses in Diner.py
        for status in Diner.STATUSES:
            # loop through each diner
            print("Diners who are", status + ":")
            for diner in self.diners:
                # if diner's status matches status, print prompt
                if diner.getStatus() == status:
                    print(diner)
        print()

    # takeOrders to take diner's order
    def takeOrders(self):
        # loop through diners in diner list
        for diner in self.diners:
            # if diner's status is ordering
            if diner.getStatus() == "ordering":
                # loop through categories in CATEGORIES class attribute
                for category in Menu.CATEGORIES:
                    # print menu for that category
                    self.menu.printMenuItems(category)
                    # error checking for valid menu item
                    userInput = -1
                    while userInput >= self.menu.getNumMenuItems(category) or userInput < 0:
                        # user's choice of menu
                        userInput = int(input(str(diner) + ", please select a " + category + " menu item number"))
                    # add item to diner
                    diner.addToOrder(self.menu.getMenuItem(category, userInput))
                    # print diner's order
                    diner.printOrder()

    # printMealCost to print cost of meal
    def printMealCost(self):
        # loop through diners in diner list
        for diner in self.diners:
            # if diner's status is paying
            if diner.getStatus() == "paying":
                # print calculation of diner's meal cost using diner.getMealCost()
                print(diner, "your meal cost is ", "$" + "{:.2f}".format(float(diner.getMealCost())))

    # removeDiners to remove a diner from list
    def removeDiners(self):
        # loop through diners in diner list
        for diner in self.diners:
            # if diner's status is leaving
            if diner.getStatus() == "leaving":
                print(diner.name, "thank you for dining with us! Come again soon!")
        # loop backwards through list of diners for removal
        for index in range(len(self.diners)-1, -1, -1):
            diner = self.diners[index]
            # if diner's status is leaving
            if diner.getStatus() == "leaving":
                # remove diner from list
                self.diners.remove(diner)

    # advanceDiners to allow waiters to attend diners at different stages and move diner to next stage
    def advanceDiners(self):
        # call printDinerStatuses, takeOrders, printMealCost, removeDiners method
        self.printDinerStatuses()
        self.takeOrders()
        self.printMealCost()
        self.removeDiners()
        # loop through each diner
        for diner in self.diners:
            # update diner's status
            diner.updateStatus()
























