# Minsoo Lee, minsoole@usc.edu
# ITP 216, Spring 2024
# Section: 31885
# Final Project
# Description: This project visualises US natural disaster data by state based on disaster type and count
#              The user may then choose to project the data to any future date before 2100

# Import Flask, os, sklearn, sqlite3, pandas, matplotlib
from flask import Flask, redirect, render_template, request, session, url_for
import os
from sklearn.linear_model import LinearRegression
import sqlite3 as sl
import pandas as pd
import matplotlib.pyplot as plt

app = Flask(__name__)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
# Store database
db = "us_disaster.db"


@app.route("/", methods=["GET"])
def mainMenu():
    """
    Checks if user has selected a state and disaster and returns appropriately.

    :return renders select.html if not selected,
    otherwise redirects to graph
    """
    # Check if user selected state/disaster and either renders select.html or redirects user to graph
    if not session.get("selected"):
        return render_template("select.html")
    else:
        return redirect(url_for("graph"))


@app.route("/action/select", methods=["POST"])
def select():
    """
    Obtain user's state and disaster and redirects user to queried graph

    :return redirects user to queried graph
    """
    # Store user's queried state and disaster in session, then redirect to graph
    session['state'] = request.form['state']
    session["disaster"] = request.form["disaster"]
    return redirect(url_for("graph", state=session['state'], disaster=session['disaster']))


@app.route("/graph/<state>/<disaster>", methods=["GET"])
def graph(state, disaster):
    """
    Load graph on visual.html with png file obtained from user's queries in select.html
    Render nodata.html if queried results have no available data
    :param state: user's selected state
    :param disaster: user's selected disaster

    :return renders nodata.html if no data available
    :return renders visual.html to load graph

    """
    # get graph png and query (for cases where no data available)
    graph_file, query = visual(state, disaster)
    # Check if query data is empty, if so then pop state and disaster from session and render nodata.html.
    # If data exists render visual.html
    if query is None or query.empty:
        session.pop("state", None)
        session.pop("disaster", None)
        # Render nodata.html to notify user of no available data
        return render_template("nodata.html")
    # Render visual.html using user's queried state, disaster, graph png file, and data
    return render_template("visual.html", disaster=disaster, state=state,
                           graph_file=graph_file)


@app.route("/action/project", methods=["POST"])
def project():
    """
    Projects user's queried data to a date selected by user in visual.html

    return: redirects user to graph with projected data
    return: if user's selected year is past 2100 or before 1800, force date as 2100 and redirect user to projected graph
    """
    # Store user's selected projection date and year obtained from date in session
    session["date"] = request.form["date"]
    selected_year = int(session["date"][0:4])

    # If user date is not between 1800 and 2100 redirect to graph force year of projection date to be 2100
    # and redirect to graph with 2100 as date
    if selected_year > 2100 or selected_year < 1800:
        session["date"] = "2100" + session["date"][4:]  # Keeping the same month and day
        return redirect(url_for("graph", state=session["state"], disaster=session["disaster"]))

    # Otherwise redirect user to graph
    return redirect(url_for("graph", state=session["state"], disaster=session["disaster"]))


@app.route("/visual", methods=["GET"])
def visual(state, disaster):
    """
    Query user's data in us_disaster.db to determine total count of the disaster grouped by year and disaster type
    Then plot data in graph using pandas. If user selects a date for projection, use scikit-learn linear regression
    to project data into the user's future selected date. Finally store graph in graph.png in static folder to be
    passed into visual.html

    :param state: user's selected state
    :param disaster: user's selected disaster

    :return graph_file as user's queried graph png and query (used to check if data is empty in graph())
    :return If
    """
    # Get user's selected state, disaster, and projection date. connect to db
    state = session.get("state")
    disaster = session.get("disaster")
    date = session.get("date")
    conn = sl.connect('us_disaster.db')

    # Query total count of disasters grouped by year and type and order by year
    user_disaster_query = """
            SELECT year, incident_type, COUNT(*) AS total_count 
            FROM us_disaster 
            WHERE state = ? AND incident_type = ? 
            GROUP BY year, incident_type 
            ORDER BY year
        """

    # Query used for checking if user's data is empty in graph()
    query = pd.read_sql_query(user_disaster_query, conn, params=(state, disaster))

    # Close connection
    conn.close()

    # If query is empty
    if query.empty:
        return None, pd.DataFrame()

    # Create pivot table for user's queried data
    pivot_table = query.pivot(index='year', columns='incident_type', values='total_count')

    # Extract years (indp variable) and total disaster count (dep variable) from data as array and reshape it to
    # column vector to be used for sklearn linear regression
    indp = pivot_table.index.values.reshape(-1, 1)
    dep = pivot_table.values.reshape(-1, 1)

    # Use LinearRegression from sklearn
    model = LinearRegression()
    # Fit x and y variables to linear regression model using fit method (This trains the model)
    model.fit(indp, dep)
    # Store projection with predict method
    projection = model.predict(indp)

    # Use pivot table to plot data on graph
    ax = pivot_table.plot(kind='line', marker='o')

    # Set title and labels and plot the regression obtained onto graph
    ax.set(title=f'Total {disaster} Disasters in {state} Grouped by Year', xlabel='Year', ylabel='Total Count')
    ax.plot(indp, projection, color='red', label='Linear Regression')

    # Projection data point to user's selected date
    if date:
        # Project number of disasters to future selected date
        # Convert date to datetime object
        # Then use regression model to find dependent variable value at respective independent variable from [0][0]
        # in array
        projected_year = pd.to_datetime(date).year
        projected_count = model.predict([[projected_year]])[0][0]

        # Create projection point with label, then add text annotation to show year (x) and
        # total projected count (y) in (x, y) format
        plt.plot(projected_year, projected_count, marker='o', color="green", markersize=5, label='Projected Data')
        plt.text(projected_year, projected_count, f'({projected_year}, {int(projected_count)})')

        # Extract most recent year and most recent count of disasters from pivot table and store in variables
        recent_year = pivot_table.index[-1]
        recent_total = pivot_table.iloc[-1].values[0]

        # Create line connecting most recent data point and projected point
        plt.plot([recent_year, projected_year], [recent_total, projected_count], color="green")

    # Create legend
    ax.legend(title='Incident Type')

    # Create graph file and save it to static folder for Flask, then close plt
    graph_file = 'static/graph.png'
    plt.savefig(graph_file)
    plt.close()

    # Return graph png file and query (for determining empty data query)
    return graph_file, query


@app.route("/action/returnmainmenu", methods=["GET", "POST"])
def returnMainMenu():
    """
    Allows user to return main menu at any time by clicking "Main Menu"

    return: redirects user back to main menu
    """
    #  Set user's session as unselected, then pop user's state and disaster
    if request.method == "POST":
        session["selected"] = False
        session.pop("state", None)
        session.pop("disaster", None)
        # redirect user to main menu
        return redirect(url_for("mainMenu"))


# Run application with secret key and debug true
if __name__ == "__main__":
    app.secret_key = os.urandom(12)
    app.run(debug=True)
