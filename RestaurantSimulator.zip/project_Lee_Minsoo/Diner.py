# Minsoo Lee, minsoole@usc.edu
# ITP 115, Spring 2021
# Final Project
# This file will define the Diner class, which will have methods to
# get the diner's name, order, status, and methods to
# update diner's status, add diner's order, print diner's order
# get diner's meal cost, and print diner's current status
from MenuItem import MenuItem

# Define diner class. Represents one diner at restaurant
class Diner(object):
    # Class variable with 5 categories for diner statuses
    STATUSES = ["seated", "ordering", "eating", "paying", "leaving"]
    # Instance attributes
    def __init__(self, name):
        self.name = name
        self.order = []
        self.status = 0 # 0 is seated status
    # define get methods for instance attributes
    def getName(self):
        return self.name
    def getOrder(self):
        return self.order
    def getStatus(self):
        return self.STATUSES[self.status]

    # define updateStatus to add 1 to self.status instance attribute
    def updateStatus(self):
        self.status += 1

    # define addToOrder to append MenuItem object to end of list of menu items
    def addToOrder(self, menuItem):
        self.order.append(menuItem)

    # Print what the diner ordered
    def printOrder(self):
        print(self.name + " ordered:")
        for item in self.order:
            print("-", item)

    # define getMealCost to calculate total meal cost
    def getMealCost(self):
        totalCost = 0
        # loop through each order and add price of item to total cost
        for item in self.order:
            totalCost += MenuItem.getPrice(item)
        return totalCost

    # __str__ for displaying message with diner's name and status
    def __str__(self):
        dinerNameStatus = "Diner " + self.name + " is currently " + Diner.STATUSES[self.status]
        return dinerNameStatus





















